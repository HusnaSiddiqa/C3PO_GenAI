from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class ConversationState:
    messages: List[Any] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    step: int = 0
