import os
import json
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Type, TypeVar
from fastapi import FastAPI, Request
from contextlib import asynccontextmanager
from langgraph.checkpoint.memory import MemorySaver
import asyncio
import time

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
)
from langchain_core.language_models import BaseChatModel
from langgraph.graph import StateGraph, END

from core.agent.ConversationState import ConversationState
from core.agent.AgentExecutor import AgentExecutor

import uvicorn
import httpx

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryPushNotifier, InMemoryTaskStore

from opentelemetry import trace
from opentelemetry.propagate import extract
from traceloop_wrapper import initialize_traceloop
from traceloop_wrapper.context import set_user_context

TState = TypeVar("TState", bound=ConversationState)
_traceloop_initialized = False


class TTLMemorySaver(MemorySaver):
    def __init__(self, ttl_seconds: int = 300):
        super().__init__()
        self.ttl = ttl_seconds
        self._timestamps: dict[str, float] = {}

    def put(self, config, checkpoint, metadata, new_versions):
        tid = config["configurable"]["thread_id"]
        self._timestamps[tid] = time.time()
        return super().put(config, checkpoint, metadata, new_versions)

    def cleanup(self):
        cutoff = time.time() - self.ttl
        expired = [tid for tid, ts in self._timestamps.items() if ts < cutoff]
        for tid in expired:
            self.storage.pop(tid, None)
            self._timestamps.pop(tid, None)
class AgentBase(ABC, Generic[TState]):

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        pass

    def __init__(self, llm: BaseChatModel, agent_skill: AgentSkill) -> None:
        self.llm = llm
        self._agent_skill = agent_skill
        self._state_type: Type[TState] = self._state_dataclass()  # type: ignore
        self._executor = AgentExecutor(self)
        self.app = FastAPI()
        self.application_name = os.getenv("APPLICATION_NAME")
        self._setup_middleware()
        self.checkpointer = TTLMemorySaver(ttl_seconds=900)  # 15 minutes TTL

    
    async def _cleanup_loop(self, checkpointer: TTLMemorySaver, interval: int = 120):
        while True:
            await asyncio.sleep(interval)
            checkpointer.cleanup()
            
    @asynccontextmanager
    async def lifespan(self, app):
        cleanup_task = asyncio.create_task(
            self._cleanup_loop(self.checkpointer)
        )
        yield
        cleanup_task.cancel()
        try:
            await cleanup_task
        except asyncio.CancelledError:
            pass
        
    def initialize_graph(self):
        graph_or_agent = self._build_graph()
        if isinstance(graph_or_agent, StateGraph):
            self._agent = graph_or_agent.compile()
        else:
            self._agent = graph_or_agent

    def invoke(self, messages: List[Dict[str, Any]], **kwargs: Any):
        """Synchronous single-shot call bypassing A2A."""
        return self._agent.invoke({"messages": messages, **kwargs})

    async def ainvoke(self, messages: List[Dict[str, Any]], **kwargs: Any):
        """Async single-shot call bypassing A2A."""
        return await self._agent.ainvoke({"messages": messages, **kwargs})

    @abstractmethod
    def _build_graph(self) -> Any:  # StateGraph or compiled agent
        """Build and return either a StateGraph or a compiled agent."""
        raise NotImplementedError

    def _state_dataclass(self) -> Type[TState]:  # pragma: no cover
        """Override to supply a custom shared-state dataclass."""
        return ConversationState  # type: ignore

    @staticmethod
    def _finish(_: ConversationState) -> str:
        """Helper for static END routing if needed."""
        return END

    def _setup_middleware(self):
        @self.app.middleware("http")
        async def inject_tracing_context(request: Request, call_next):
            body = await request.body()
            metadata = json.loads(body).get("params", {}).get("metadata", {}) if body else {}
            user_id = metadata.get("user_id")
            conversation_id = metadata.get("conversation_id")

            context = extract(request.headers)
            tracer = trace.get_tracer("AgentTracing")
            if user_id and conversation_id:
                set_user_context(user_id, conversation_id)
            with tracer.start_as_current_span(f"{self.application_name}_{self.name}", context=context) as span:
                if user_id is not None:
                    span.set_attribute("user.id", user_id)
                if conversation_id is not None:
                    span.set_attribute("conversation.id", conversation_id)

                response = await call_next(request)

            return response

    def run_server(self, host="0.0.0.0", port=8000, host_base_url: str = "http://localhost:8000",
                   path: str = "/agents/", dynatrace_endpoint: str = None, dynatrace_auth_token: str = None):
        if self._agent_skill:
            capabilities = AgentCapabilities(streaming=True, pushNotifications=True)
            agent_card = AgentCard(
                name=self.name,
                description=self.description,
                url=f'{host_base_url}{path}',
                version='1.0.0',
                defaultInputModes=['text', 'text/plain'],
                defaultOutputModes=['text', 'text/plain'],
                capabilities=capabilities,
                skills=[self._agent_skill],
            )
            httpx_client = httpx.AsyncClient()
            request_handler = DefaultRequestHandler(
                agent_executor=self._executor,
                task_store=InMemoryTaskStore(),
                push_notifier=InMemoryPushNotifier(httpx_client),
            )
            server = A2AStarletteApplication(
                agent_card=agent_card, http_handler=request_handler
            ).build()
            app = self.app

            global _traceloop_initialized
            if not _traceloop_initialized:
                initialize_traceloop(
                    app_name=f"{self.application_name}_{self.name}",
                    endpoint=dynatrace_endpoint,
                    auth_token=dynatrace_auth_token,
                )
                _traceloop_initialized = True

            app.mount(path, server)
            print(f"Starting A2A agent server at {host_base_url}/ with skill '{self._agent_skill.id}'")
            uvicorn.run(app, host=host, port=port)
        else:
            raise Exception("Provide Agent Skills!")
