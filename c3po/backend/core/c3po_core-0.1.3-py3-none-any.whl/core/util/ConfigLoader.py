import boto3
import json
import os
from botocore.exceptions import ClientError
from dotenv import load_dotenv


def get_secret(secret_name, region_name="us-west-2"):
    client = boto3.client("secretsmanager", region_name=region_name)

    try:
        response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        raise Exception(f"Unable to retrieve secret: {e}")

    if "SecretString" in response:
        secret = response["SecretString"]
        try:
            return json.loads(secret)  # If it's a JSON string
        except json.JSONDecodeError:
            return secret  # Return as plain string
    else:
        return response["SecretBinary"]


def load_env_variables(env_file=".env"):
    load_dotenv(env_file)
    return {key: os.getenv(key) for key in os.environ.keys()}
