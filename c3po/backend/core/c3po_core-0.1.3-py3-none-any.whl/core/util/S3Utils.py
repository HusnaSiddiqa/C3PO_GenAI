import boto3
from botocore.exceptions import ClientError, BotoCoreError
from typing import Optional, List, Dict, Any


class S3Utils:
    def __init__(self, aws_region: str = "us-west-2"):
        self.aws_region = aws_region
        self.s3_client = boto3.client("s3", region_name=aws_region)

    def put_object(
        self, 
        bucket_name: str, 
        key: str, 
        data: Any, 
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None
    ) -> bool:

        try:
            extra_args = {}
            if content_type:
                extra_args['ContentType'] = content_type
            if metadata:
                extra_args['Metadata'] = metadata
                
            self.s3_client.put_object(
                Bucket=bucket_name,
                Key=key,
                Body=data,
                **extra_args
            )
            return True
        except (ClientError, BotoCoreError) as e:
            print(f"Error uploading object to S3: {e}")
            return False

    def get_object(
        self, 
        bucket_name: str, 
        key: str
    ) -> Optional[bytes]:

        try:
            response = self.s3_client.get_object(Bucket=bucket_name, Key=key)
            return response["Body"].read()
        except self.s3_client.exceptions.NoSuchKey:
            print(f"Object '{key}' not found in bucket '{bucket_name}'")
            return None
        except (ClientError, BotoCoreError) as e:
            print(f"Error downloading object from S3: {e}")
            return None

    def list_objects(
        self, 
        bucket_name: str, 
        prefix: str = "", 
        max_keys: int = 1000
    ) -> List[Dict[str, Any]]:
        
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=bucket_name,
                Prefix=prefix,
                MaxKeys=max_keys
            )
            return response.get("Contents", [])
        except (ClientError, BotoCoreError) as e:
            print(f"Error listing objects in S3: {e}")
            return []

    def delete_object(
        self, 
        bucket_name: str, 
        key: str
    ) -> bool:

        try:
            self.s3_client.delete_object(Bucket=bucket_name, Key=key)
            return True
        except (ClientError, BotoCoreError) as e:
            print(f"Error deleting object from S3: {e}")
            return False

    def object_exists(
        self, 
        bucket_name: str, 
        key: str
    ) -> bool:
        
        try:
            self.s3_client.head_object(Bucket=bucket_name, Key=key)
            return True
        except self.s3_client.exceptions.NoSuchKey:
            return False
        except (ClientError, BotoCoreError) as e:
            print(f"Error checking object existence in S3: {e}")
            return False

    def get_object_metadata(
        self, 
        bucket_name: str, 
        key: str
    ) -> Optional[Dict[str, Any]]:
       
        try:
            response = self.s3_client.head_object(Bucket=bucket_name, Key=key)
            return {
                "ContentType": response.get("ContentType"),
                "ContentLength": response.get("ContentLength"),
                "LastModified": response.get("LastModified"),
                "ETag": response.get("ETag"),
                "Metadata": response.get("Metadata", {})
            }
        except self.s3_client.exceptions.NoSuchKey:
            print(f"Object '{key}' not found in bucket '{bucket_name}'")
            return None
        except (ClientError, BotoCoreError) as e:
            print(f"Error getting object metadata from S3: {e}")
            return None 