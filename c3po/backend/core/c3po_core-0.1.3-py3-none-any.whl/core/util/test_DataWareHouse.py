import pytest
import json
import pandas as pd
from unittest.mock import MagicMock, patch, call
from databricks.sql.exc import RequestError
import os
from DataWareHouse import DataWarehouse


HOST = "dbc-cb51d0ac-685d.cloud.databricks.com"
HTTP_PATH = "/sql/1.0/warehouses/7cdcc2e4901aed9c"
TOKEN = "dapi0e008256a55e73dbde889f76d0ff9861"


def make_dw(user_email=None):
    return DataWarehouse(HOST, HTTP_PATH, TOKEN, user_email=user_email)

def test_connect_and_query(query: str):
    dw = make_dw("sristi.raj5@gilead.com")
    result = dw.get_data_from_wareshouse(query)
    print(result)
# ---------------------------------------------------------------------------
# connect()
# ---------------------------------------------------------------------------

class TestConnect:
    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_connect_calls_sql_connect_with_correct_args(self, mock_sql):
        mock_sql.connect.return_value = MagicMock()
        dw = make_dw()

        dw.connect()

        mock_sql.connect.assert_called_once_with(
            server_hostname=HOST,
            http_path=HTTP_PATH,
            access_token=TOKEN,
            _tls_no_verify=True,
        )

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_connect_returns_connection_object(self, mock_sql):
        fake_conn = MagicMock()
        mock_sql.connect.return_value = fake_conn
        dw = make_dw()

        result = dw.connect()

        assert result is fake_conn

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_connect_propagates_exceptions(self, mock_sql):
        mock_sql.connect.side_effect = Exception("connection refused")
        dw = make_dw()

        with pytest.raises(Exception, match="connection refused"):
            dw.connect()


# ---------------------------------------------------------------------------
# get_data_from_wareshouse()
# ---------------------------------------------------------------------------

def _build_cursor_mock(rows, columns):
    """Return a cursor mock whose fetchall/description match given rows/columns."""
    cursor = MagicMock()
    cursor.execute.return_value = cursor
    cursor.fetchall.return_value = rows
    cursor.description = [(col,) for col in columns]
    return cursor


def _conn_ctx(cursor_mock):
    """Return a context-manager connection mock that yields a cursor."""
    conn = MagicMock()
    conn.__enter__ = MagicMock(return_value=conn)
    conn.__exit__ = MagicMock(return_value=False)
    conn.cursor.return_value = cursor_mock
    return conn


class TestGetDataFromWarehouse:

    # -- happy path ----------------------------------------------------------

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_returns_json_records(self, mock_sql):
        rows = [("Alice", 30), ("Bob", 25)]
        cursor = _build_cursor_mock(rows, ["name", "age"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        result = dw.get_data_from_wareshouse("SELECT name, age FROM users")

        data = json.loads(result)
        assert len(data) == 2
        assert data[0]["name"] == "Alice"
        assert data[1]["age"] == 25

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_sets_statement_timeout(self, mock_sql):
        cursor = _build_cursor_mock([("x",)], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        dw.get_data_from_wareshouse("SELECT 1")

        timeout_call = call("SET STATEMENT_TIMEOUT = 1000;")
        assert timeout_call in cursor.execute.call_args_list

    # -- user_email session variable -----------------------------------------

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_sets_session_variable_when_user_email_provided(self, mock_sql):
        cursor = _build_cursor_mock([("x",)], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw(user_email="user@example.com")
        dw.get_data_from_wareshouse("SELECT 1")

        declare_call = call(
            "DECLARE OR REPLACE variable sess_user_email STRING DEFAULT 'user@example.com'"
        )
        assert declare_call in cursor.execute.call_args_list

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_skips_session_variable_when_no_user_email(self, mock_sql):
        cursor = _build_cursor_mock([("x",)], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        dw.get_data_from_wareshouse("SELECT 1")

        calls_str = " ".join(str(c) for c in cursor.execute.call_args_list)
        assert "sess_user_email" not in calls_str

    # -- init function env var -----------------------------------------------

    @patch.dict("os.environ", {"ENABLE_INIT_FUNCTION": "true", "DB_INIT_FUNCTION": "my_init_fn"})
    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_calls_init_function_when_env_enabled(self, mock_sql):
        cursor = _build_cursor_mock([("x",)], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        dw.get_data_from_wareshouse("SELECT 1")

        init_call = call("SELECT my_init_fn()")
        assert init_call in cursor.execute.call_args_list

    @patch.dict("os.environ", {"ENABLE_INIT_FUNCTION": "false"}, clear=False)
    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_skips_init_function_when_env_disabled(self, mock_sql):
        cursor = _build_cursor_mock([("x",)], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        dw.get_data_from_wareshouse("SELECT 1")

        calls_str = " ".join(str(c) for c in cursor.execute.call_args_list)
        assert "my_init_fn" not in calls_str

    # -- empty result set -----------------------------------------------------

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_raises_value_error_on_empty_result(self, mock_sql):
        cursor = _build_cursor_mock([], ["col"])
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        with pytest.raises(ValueError, match="Query has returned no data"):
            dw.get_data_from_wareshouse("SELECT 1 WHERE 1=0")

    # -- RequestError retry logic ---------------------------------------------

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_retries_on_request_error_up_to_3_times(self, mock_sql):
        cursor = MagicMock()
        cursor.execute.side_effect = RequestError("timeout", None)
        conn = _conn_ctx(cursor)
        mock_sql.connect.return_value = conn

        dw = make_dw()
        result = dw.get_data_from_wareshouse("SELECT 1")

        assert result == ""
        assert mock_sql.connect.call_count == 4  # initial + 3 retries

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_succeeds_on_second_attempt_after_request_error(self, mock_sql):
        good_cursor = _build_cursor_mock([("ok",)], ["status"])
        good_conn = _conn_ctx(good_cursor)

        bad_cursor = MagicMock()
        bad_cursor.execute.side_effect = RequestError("flaky", None)
        bad_conn = _conn_ctx(bad_cursor)

        mock_sql.connect.side_effect = [bad_conn, good_conn]

        dw = make_dw()
        result = dw.get_data_from_wareshouse("SELECT 1")

        data = json.loads(result)
        assert data[0]["status"] == "ok"

    # -- non-RequestError propagation ----------------------------------------

    @patch("c3po.backend.core.util.DataWareHouse.sql")
    def test_non_request_error_is_propagated(self, mock_sql):
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("unexpected")
        mock_sql.connect.return_value = _conn_ctx(cursor)

        dw = make_dw()
        with pytest.raises(RuntimeError, match="unexpected"):
            dw.get_data_from_wareshouse("SELECT 1")

if __name__ == "__main__":
    os.environ["ENABLE_INIT_FUNCTION"]="true"
    os.environ["DB_INIT_FUNCTION"]="`gna-hr-gen-ai-dev`.gna_hr_unity.create_secured_temp_views"
    test_connect_and_query("""SELECT *
FROM 
    `tmp_x_job_events_secured` LIMIT 10""")
    