from langchain_aws import ChatBedrockConverse as ChatBedrock
from typing import Any
import boto3
import os
from botocore.config import Config

# Inference parameters supported by each model family via the Bedrock Converse API.
# More specific prefixes must come before broader ones — first match wins.
# Claude 3.7+ uses extended thinking and does not support temperature, top_p, or top_k.
_MODEL_SUPPORTED_PARAMS: list[tuple[str, set[str]]] = [
    ("anthropic.claude-3-7",  {"max_tokens", "stop_sequences"}),
    ("anthropic.claude-4",    {"max_tokens", "stop_sequences"}),
    ("anthropic.claude",      {"temperature", "max_tokens", "top_p", "top_k", "stop_sequences"}),
    ("amazon.titan",          {"temperature", "max_tokens", "top_p"}),
    ("amazon.nova",           {"temperature", "max_tokens", "top_p"}),
    ("meta.llama",            {"temperature", "max_tokens", "top_p"}),
    ("mistral.mistral",       {"temperature", "max_tokens", "top_p"}),
    ("mistral.mixtral",       {"temperature", "max_tokens", "top_p"}),
    ("cohere.command",        {"temperature", "max_tokens", "top_p", "stop_sequences"}),
    ("ai21.jamba",            {"temperature", "max_tokens", "top_p"}),
]

_FALLBACK_PARAMS: set[str] = {"max_tokens"}

# Model prefixes that support latency-optimized inference via performanceConfig.
# More specific prefixes must come before broader ones — first match wins.
_LATENCY_OPTIMIZED_SUPPORTED: list[str] = [
    "anthropic.claude-3-5",
    "anthropic.claude-3-haiku",
    "amazon.nova",
]


_INFERENCE_PROFILE_PREFIXES = ("global.", "us.", "eu.", "ap.")


def _strip_profile_prefix(model_id: str) -> str:
    for prefix in _INFERENCE_PROFILE_PREFIXES:
        if model_id.startswith(prefix):
            return model_id[len(prefix):]
    return model_id


def _supported_params(model_id: str) -> set[str]:
    model_id = _strip_profile_prefix(model_id)
    for prefix, params in _MODEL_SUPPORTED_PARAMS:
        if model_id.startswith(prefix):
            return params
    return _FALLBACK_PARAMS


def _supports_latency_optimized(model_id: str) -> bool:
    model_id = _strip_profile_prefix(model_id)
    return any(model_id.startswith(prefix) for prefix in _LATENCY_OPTIMIZED_SUPPORTED)


class BedrockProvider:

    def __init__(
        self,
        model_name: str = "anthropic.claude-3-sonnet-20240229",
        region: str = "us-west-2",
        **kwargs: Any,
    ):
        self.model_name = model_name
        self.region = region
        self.extra_kwargs = kwargs
        network_config = Config(
            read_timeout=1500,  # Allow up to 15 minutes for a response
            connect_timeout=250,  # Allow up to 4 minutes for the connection to be established
        )
        # boto3 automatically picks up IRSA credentials on EKS pods via
        # AWS_WEB_IDENTITY_TOKEN_FILE + AWS_ROLE_ARN env vars injected by the pod identity webhook
        session = boto3.Session(region_name=region)
        self.boto3_client = session.client(service_name="bedrock-runtime", config=network_config)

    def get_llm(self) -> ChatBedrock:
        allowed = _supported_params(self.model_name)
        filtered_kwargs = {k: v for k, v in self.extra_kwargs.items() if k in allowed}

        latency_optimized = (
            os.getenv("ENABLE_LATENCY_OPTIMIZED_INFERENCE", "").lower() in ("1", "true")
            and _supports_latency_optimized(self.model_name)
        )
        if latency_optimized:
            filtered_kwargs["performance_config"] = {"latency": "optimized"}

        return ChatBedrock(
            model=self.model_name,
            client=self.boto3_client,
            **filtered_kwargs,
        )
