from langchain_openai import ChatOpenAI
from typing import Any


class MosaicProvider:

    def __init__(
        self,
        model_name: str,
        api_key: str,
        base_url: str,
        **kwargs: Any,
    ):
        self.model_name = model_name
        self.api_key = api_key
        self.base_url = base_url
        self.extra_kwargs = kwargs

    def get_llm(self) -> ChatOpenAI:
        return ChatOpenAI(
            model=self.model_name,
            api_key=self.api_key,
            base_url=self.base_url,
            **self.extra_kwargs,
        )
