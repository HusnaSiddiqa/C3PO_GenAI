import mlflow
from mlflow.tracking import MlflowClient
import os
import requests
from datetime import datetime
from typing import Optional
from core.util.ConfigLoader import load_env_variables, get_secret


class PromptStore:
    def __init__(self, prompt_type: str, prompt_path: str):
        env = load_env_variables()
        mlflow.set_tracking_uri("databricks")
        secret_name = 'SECRET_NAME'
        if secret_name not in env:
            raise KeyError(f"Missing required environment variable(s): {secret_name}")
        secret_name = env['SECRET_NAME']
        model_api_key = get_secret(secret_name)
        os.environ["DATABRICKS_TOKEN"] = model_api_key
        self.client = MlflowClient()
        self.prompt_type = prompt_type
        self.prompt_path = prompt_path
        self.experiment_path = f"/{prompt_path}/{prompt_type}"
        self.ensure_workspace_path_exists()
        # Create experiment if it doesn't exist
        experiment = self.client.get_experiment_by_name(self.experiment_path)
        if not experiment:
            self.experiment_id = self.client.create_experiment(self.experiment_path)
        else:
            self.experiment_id = experiment.experiment_id

    # Create folders if they don't exist
    def ensure_workspace_path_exists(self):
        token = os.getenv("DATABRICKS_TOKEN")
        workspace_url = os.getenv("DATABRICKS_HOST")
        current_path = self.prompt_path
        if not current_path.startswith("/"):
            current_path = "/" + current_path
        response = requests.get(
            f"{workspace_url}/api/2.0/workspace/get-status",
            headers={"Authorization": f"Bearer {token}"},
            params={"path": current_path}
        )
        if response.status_code == 404:
            requests.post(
                f"{workspace_url}/api/2.0/workspace/mkdirs",
                headers={"Authorization": f"Bearer {token}"},
                json={"path": current_path}
            )

    def _get_timestamp_version(self) -> str:
        return datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")

    def _get_next_version_alias(self) -> str:
        runs = self.client.search_runs(
            [self.experiment_id],
            order_by=["tags.version_alias DESC"],
        )
        version_numbers = []
        for run in runs:
            alias = run.data.tags.get("version_alias")
            if alias:
                try:
                    version_numbers.append(float(alias))
                except ValueError:
                    continue
        last_version = max(version_numbers, default=0.9)
        next_version = round(last_version + 0.1, 1)
        return f"{next_version:.1f}"

    def store_prompt(self, prompt: str, **kwargs):
        version = self._get_timestamp_version()
        version_alias = self._get_next_version_alias()
        filename = f"{self.prompt_type}_{version_alias}.txt"

        local_path = f"/tmp/{filename}"

        with open(local_path, "w", encoding="utf-8") as f:
            f.write(prompt)

        with mlflow.start_run(run_name=f"{self.prompt_type}_{version_alias}", experiment_id=self.experiment_id):
            mlflow.set_tag("prompt_type", self.prompt_type)
            mlflow.set_tag("version", version)
            mlflow.set_tag("version_alias", version_alias)
            for key, value in kwargs.items():
                if value is not None:
                    mlflow.set_tag(key, value)

            mlflow.log_artifact(local_path, artifact_path="artifacts")

        os.remove(local_path)
        return version_alias

    def load_prompt(self, version_alias: Optional[str] = None, version: Optional[str] = None) -> dict[str, str]:
        if version_alias:
            filter_string = f"tags.version_alias = '{version_alias}'"
        elif version:
            filter_string = f"tags.version = '{version}'"
        else:
            filter_string = ""

        runs = self.client.search_runs(
            [self.experiment_id],
            filter_string=filter_string,
            order_by=["tags.version DESC" if not version and not version_alias else "start_time DESC"],
            max_results=1
        )

        if not runs:
            raise ValueError("Prompt not found with the specified filters")

        run = runs[0]
        run_id = run.info.run_id
        version_alias = run.data.tags.get("version_alias")
        tags = run.data.tags
        filename = f"{self.prompt_type}_{version_alias}.txt"

        local_path = mlflow.artifacts.download_artifacts(
            run_id=run_id,
            artifact_path=f"artifacts/{filename}"
        )

        with open(local_path, encoding="utf-8") as f:
            prompt = f.read()

        return {"prompt": prompt, **tags}

    def delete_prompt(self) -> bool:
        try:
            self.client.delete_experiment(self.experiment_id)
            return True
        except Exception as e:
            return False

    def list_versions(self):
        runs = self.client.search_runs(
            [self.experiment_id],
            order_by=["tags.version DESC"],
        )
        return [r.data.tags.get("version_alias") for r in runs if "version_alias" in r.data.tags]
