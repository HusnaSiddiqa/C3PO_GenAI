from typing import Optional
from .SystemPrompt import SystemPrompt
from .AdminPrompt import AdminPrompt
from core.util.S3Utils import S3Utils


class Prompt:
    def __init__(self, s3_bucket, system_prompt_prefix, admin_prompt_name, template_prefix, region="us-west-2"):
        self.system_prompt = SystemPrompt(s3_bucket, system_prompt_prefix, region)
        self.admin_prompt = AdminPrompt(admin_prompt_name)
        self.template_prefix = template_prefix
        self.region = region
        self.s3_utils = S3Utils(region)
        self.s3_bucket = s3_bucket
    
    def get_prompt(self, prompt_name: str, admin_prompt_version: int = 1) -> Optional[str]:

        system_content = self.system_prompt.get_system_prompt(prompt_name)
        if system_content is None:
            print(f"Failed to load system prompt: {prompt_name}")
            return None

        admin_content = self.admin_prompt.get_admin_prompt(admin_prompt_version)
        if admin_content is None:
            print(f"Failed to load admin prompt version: {admin_prompt_version}")
            return None

        template = self._get_template(self.template_prefix)
        combined_prompt = self._combine_prompts(template, system_content, admin_content)
        return combined_prompt

    def _get_template(self, template_name: str):
        return self.s3_utils.get_object(self.s3_bucket, template_name)

    @staticmethod
    def _combine_prompts(template, system_content: str, admin_content: str) -> str:

        final_string = template.format(admin_prompt=admin_content, system_prompt=system_content)

        return final_string
