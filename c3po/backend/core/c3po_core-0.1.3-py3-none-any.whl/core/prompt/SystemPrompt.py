from core.util.S3Utils import S3Utils


class SystemPrompt:
    def __init__(self, s3_bucket, s3_prefix, aws_region="us-west-2"):
        self.s3_bucket = s3_bucket
        self.s3_prefix = s3_prefix
        self.s3_utils = S3Utils(aws_region)

    def register_system_prompt(self, prompt_name, prompt_content):
        key = f"{self.s3_prefix}/{prompt_name}.txt"
        success = self.s3_utils.put_object(
            bucket_name=self.s3_bucket,
            key=key,
            data=prompt_content
        )
        if success:
            return f"s3://{self.s3_bucket}/{key}"
        return None

    def get_system_prompt(self, prompt_name):
        key = f"{self.s3_prefix}/{prompt_name}"
        content = self.s3_utils.get_object(self.s3_bucket, key)
        if content is not None:
            return content.decode("utf-8")
        print(f"Prompt '{prompt_name}' not found in S3.")
        return None

    def list_system_prompts(self):
        objects = self.s3_utils.list_objects(
            bucket_name=self.s3_bucket,
            prefix=self.s3_prefix
        )
        return [obj["Key"].split("/")[-1].replace(".txt", "") for obj in objects]

    def delete_system_prompt(self, prompt_name):
        key = f"{self.s3_prefix}/{prompt_name}.txt"
        success = self.s3_utils.delete_object(self.s3_bucket, key)
        if success:
            return f"Deleted {prompt_name} from S3"
        return None
