from mlflow import register_prompt, load_prompt
from mlflow.exceptions import MlflowException


class AdminPrompt:

    def __init__(self, name):
        self.name = name

    def register_or_update_admin_prompt(self, template, commit_message=None, version_metadata=None, tags=None):
        try:
            return register_prompt(
                name=self.name,
                template=template,
                commit_message=commit_message,
                version_metadata=version_metadata,
                tags=tags
            )
        except MlflowException as e:
            print(f"Error registering prompt in MLflow: {e}")
            return None

    def get_admin_prompt(self, prompt_version="latest"):
        try:
            return load_prompt(f"prompts:/{self.name}/{prompt_version}")
        except MlflowException as e:
            print(f"Error loading prompt from MLflow: {e}")
            return None
