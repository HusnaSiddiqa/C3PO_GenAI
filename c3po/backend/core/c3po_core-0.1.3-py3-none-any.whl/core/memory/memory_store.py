import json
from typing import List, Dict, Optional
from core.util.S3Utils import S3Utils


class MemoryStore:
    def __init__(self, bucket_name: str, prefix: str = "", region_name: str = "us-west-2"):
        self.bucket_name = bucket_name
        self.prefix = prefix.rstrip("/") + "/" if prefix else ""
        self.s3_utils = S3Utils(region_name)

    def _build_key(self, user_name: str, agent_name: str, conversation_id: Optional[str] = None) -> str:
        parts = [user_name, agent_name]
        if conversation_id:
            parts.append(conversation_id)
        return self.prefix + "/".join(parts) + ".json"

    def search(self, user_name: str, agent_name: str, conversation_id: str, last_n: Optional[int] = None) -> Optional[
        List[Dict]]:
        key = self._build_key(user_name, agent_name, conversation_id)
        try:
            response = self.s3_utils.get_object(self.bucket_name, key)
            content = response.decode("utf-8")
            messages = json.loads(content)
            if last_n is not None:
                return messages[-last_n:]

            return messages


        except Exception as e:
            return []

    def save(self, messages: List[Dict], user_name: str, agent_name: str, conversation_id: str):
        key = self._build_key(user_name, agent_name, conversation_id)
        try:
            existing_message = self.search(user_name, agent_name, conversation_id)

            updated_message = (existing_message + messages)
            self.s3_utils.put_object(
                bucket_name=self.bucket_name,
                key=key,
                data=json.dumps(updated_message)
            )
        except Exception as e:
            return []
