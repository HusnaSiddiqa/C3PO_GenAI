import os
# import threading
# import time
# import psutil
from opentelemetry import metrics, trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.metrics import MeterProvider, Counter, Histogram
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.metrics.export import (
    PeriodicExportingMetricReader,
    AggregationTemporality,
)
from traceloop_wrapper.context import get_user_context

temporality = AggregationTemporality.DELTA

_meter = None
_counters = {}

def _add_user_context(attrs: dict = None) -> dict:
    ctx = get_user_context()
    attrs = attrs or {}
    if ctx.get("user.id"):
        attrs["user.id"] = ctx["user.id"]
    if ctx.get("conversation.id"):
        attrs["conversation.id"] = ctx["conversation.id"]

    return attrs

def initialize_metrics(app_name="llm-app", otlp_endpoint=None, token=None):
    global _meter, _counters

    endpoint = otlp_endpoint or os.getenv("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT")
    if not endpoint:
        print("[TraceLoop Wrapper] Warning: No OTLP metrics endpoint configured.")
        return

    resource = Resource(attributes={"service.name": app_name})
    exporter = OTLPMetricExporter(endpoint=endpoint, headers={
        "Authorization": token},
                                  preferred_temporality={Counter: temporality, Histogram: AggregationTemporality.DELTA})
    reader = PeriodicExportingMetricReader(exporter)
    provider = MeterProvider(resource=resource, metric_readers=[reader])
    metrics.set_meter_provider(provider)
    _meter = metrics.get_meter("traceloop_wrapper")
    _counters["tokens"] = _meter.create_counter(f"{app_name}_total_tokens", unit="1", description="Total tokens used")
    _counters["cost"] = _meter.create_counter(f"{app_name}_total_cost_usd", unit="USD", description="Total cost in USD")
    _counters["errors"] = _meter.create_counter(f"{app_name}_errors", unit="1", description="LLM pipeline errors")
    _counters["feedback"] = _meter.create_histogram(f"{app_name}_feedback_score", unit="score",
                                                    description="User feedback")
    _counters["latency"] = _meter.create_histogram(f"{app_name}_latency_ms", unit="ms",
                                                   description="LLM processing latency")
    _counters["response_time"] = _meter.create_histogram(f"{app_name}_response_time_ms", unit="ms",
                                                        description="End-to-end user response time")
    _counters["requests"] = _meter.create_counter(f"{app_name}_request_count", unit="1",
                                                 description="Total user requests")
    _counters["memory_mb"] = _meter.create_histogram(f"{app_name}_memory_usage_mb", unit="MB",
                                                    description="Memory usage of the process")
    _counters["io_bytes"] = _meter.create_histogram(f"{app_name}_io_bytes", unit="bytes",
                                                   description="Disk I/O usage (read+write)")

    # start_system_metrics_loop()
    print(f"[TraceLoop Wrapper] Metric exporter initialized at:: {endpoint}")


def record_tokens(count, attrs=None):
    _counters["tokens"].add(count, _add_user_context(attrs))


def record_cost(amount, attrs=None):
    _counters["cost"].add(amount, _add_user_context(attrs))


def record_error(attrs=None):
    _counters["errors"].add(1, _add_user_context(attrs))


def record_latency(ms, attrs=None):
    _counters["latency"].record(ms, _add_user_context(attrs))

def record_request(attrs=None):
    span = trace.get_current_span()
    print(f"[DEBUG] Recording metric from span: {span.get_span_context().span_id}")
    _counters["requests"].add(1, _add_user_context(attrs))

def record_response_time(ms, attrs=None):
    _counters["response_time"].record(ms, _add_user_context(attrs))

def record_feedback(score, attrs=None):
    _counters["feedback"].record(score, _add_user_context(attrs))

# def _system_metrics_loop(attrs=None, interval=60):
#     while True:
#         try:
#             mem = psutil.Process().memory_info().rss / (1024 ** 2)  # MB
#             io = psutil.disk_io_counters()
#             total_bytes = io.read_bytes + io.write_bytes
#
#             _counters["memory_mb"].record(mem, _add_user_context(attrs))
#             _counters["io_bytes"].record(total_bytes, _add_user_context(attrs))
#
#             print(f"[SystemMetrics] Memory: {round(mem, 2)} MB | I/O Bytes: {total_bytes}")
#         except Exception as e:
#             print("[SystemMetrics] Error:", e)
#
#         time.sleep(interval)
#
# def start_system_metrics_loop(attrs=None, interval=60):
#     thread = threading.Thread(target=_system_metrics_loop, args=(attrs, interval), daemon=True)
#     thread.start()