from .tracer import setup_tracer
from .llm_hooks import patch_all
from .metrics import initialize_metrics
from .context import set_user_context

def initialize_traceloop(app_name, endpoint, auth_token, user_id=None, conversation_id=None):
    if user_id and conversation_id:
        set_user_context(user_id, conversation_id)
    metrics_endpoint = endpoint + "/v1/metrics"
    setup_tracer(app_name, endpoint, auth_token)
    initialize_metrics(app_name, metrics_endpoint, auth_token)
    patch_all()
