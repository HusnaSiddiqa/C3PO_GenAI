_user_context = {}

def set_user_context(user_id: str, conversation_id: str):
    print('Setting user context', user_id, conversation_id)
    global _user_context
    _user_context = {
        "user.id": user_id,
        "conversation.id": conversation_id
    }

def get_user_context():
    return _user_context
