import logging

logger = logging.getLogger(__name__)

def extract_usage_openai(response):
    try:
        return response.get("usage", {})
    except Exception as e:
        logger.warning(f"[OpenAI] Failed to extract usage: {e}")
        return {}

def extract_usage_langchain(response):
    try:
        if hasattr(response, "llm_output") and "total_tokens" in response.llm_output:
            return response.llm_output

        if hasattr(response, "response_metadata"):
            return response.response_metadata

        generations = response.generations
        if generations and generations[0]:
            ai_message = generations[0][0].message
            return getattr(ai_message, "response_metadata", {})

        logger.warning("[LangChain] No usage info found in LLMResult.")
        return {}
    except Exception as e:
        logger.warning(f"[LangChain] Failed to extract usage: {e}")
        return {}

def extract_usage_bedrock(response_dict):
    try:
        if "usage" in response_dict:
            return response_dict["usage"]
        return {}
    except Exception as e:
        logger.warning(f"[Bedrock] Failed to extract usage: {e}")
        return {}

def calculate_cost(usage):
    prompt_tokens = usage.get("prompt_tokens", 0)
    completion_tokens = usage.get("completion_tokens", 0)
    price_per_million_prompt = 3.00
    price_per_million_completion = 15.00
    return (prompt_tokens / 1_000_000 * price_per_million_prompt) + (completion_tokens / 1_000_000 * price_per_million_completion)