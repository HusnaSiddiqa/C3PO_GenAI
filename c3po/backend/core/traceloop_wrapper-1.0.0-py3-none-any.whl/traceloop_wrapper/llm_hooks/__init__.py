from .openai_hook import patch_openai
from .langchain_hook import patch_langchain
from .bedrock_hook import patch_bedrock
from .async_openai_hook import patch_openai_async

def patch_all():
    patch_openai()
    patch_langchain()
    patch_bedrock()
    patch_openai_async()
