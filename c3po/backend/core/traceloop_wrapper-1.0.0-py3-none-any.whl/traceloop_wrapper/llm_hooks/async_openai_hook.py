from functools import wraps
from time import perf_counter
from openai import AsyncOpenAI

from traceloop_wrapper.metrics import (
    record_tokens,
    record_cost,
    record_latency,
    record_request,
    record_error
)
from traceloop_wrapper.usage_utils import extract_usage_openai, calculate_cost


def patch_openai_async():
    original_init = AsyncOpenAI.__init__

    def patched_init(self, *args, **kwargs):
        # Run the original __init__ method
        original_init(self, *args, **kwargs)

        # Now patch the completions.create method
        if hasattr(self, "chat") and hasattr(self.chat, "completions"):
            original_create = self.chat.completions.create

            @wraps(original_create)
            async def wrapped_create(*c_args, **c_kwargs):
                model = c_kwargs.get("model", "unknown")
                messages = c_kwargs.get("messages", [])
                temperature = c_kwargs.get("temperature", 1.0)

                start = perf_counter()
                try:
                    record_request({"llm.provider": "openai", "llm.model": model})
                    response = await original_create(*c_args, **c_kwargs)
                    duration_ms = (perf_counter() - start) * 1000

                    usage = extract_usage_openai(response)
                    cost = calculate_cost(usage)
                    completion = response.choices[0].message.content

                    record_tokens(usage.get("total_tokens", 0), {"llm.provider": "openai", "llm.model": model})
                    record_cost(cost, {"llm.provider": "openai", "llm.model": model})
                    record_latency(duration_ms, {"llm.provider": "openai", "llm.model": model})

                    return response

                except Exception:
                    record_error({"llm.provider": "openai", "llm.model": model})
                    raise

            self.chat.completions.create = wrapped_create
            print("[TraceLoop Wrapper] Patched AsyncOpenAI.chat.completions.create with metrics")

    AsyncOpenAI.__init__ = patched_init
