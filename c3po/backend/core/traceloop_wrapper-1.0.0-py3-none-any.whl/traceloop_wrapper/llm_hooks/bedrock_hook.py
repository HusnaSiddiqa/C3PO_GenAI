import json
import boto3
from functools import wraps
from time import perf_counter

from traceloop_wrapper.metrics import (
    record_tokens,
    record_cost,
    record_latency,
    record_request,
    record_error
)
from traceloop_wrapper.usage_utils import extract_usage_bedrock, calculate_cost

def patch_bedrock():
    try:
        bedrock_runtime = boto3.client("bedrock-runtime")
        original_invoke = bedrock_runtime.invoke_model
    except Exception:
        print("[TraceLoop Wrapper] boto3 or Bedrock runtime unavailable, skipping patch.")
        return

    @wraps(original_invoke)
    def patched_invoke_model(*args, **kwargs):
        model_id = kwargs.get("modelId", "unknown")
        body_raw = kwargs.get("body", "{}")

        try:
            body = json.loads(body_raw)
        except Exception:
            body = {}

        base_provider = model_id.split(".")[0] if "." in model_id else "unknown"
        model_name = model_id.split(".")[-1]

        start = perf_counter()
        try:
            record_request({"llm.provider": "bedrock", "llm.model": model_name})
            response = original_invoke(*args, **kwargs)
            duration_ms = (perf_counter() - start) * 1000

            result_str = response["body"].read().decode("utf-8")
            result = json.loads(result_str)

            usage = extract_usage_bedrock(result)
            cost = calculate_cost(usage)

            record_tokens(usage.get("total_tokens", 0), {"llm.provider": "bedrock", "llm.model": model_name})
            record_cost(cost, {"llm.provider": "bedrock", "llm.model": model_name})
            record_latency(duration_ms, {"llm.provider": "bedrock", "llm.model": model_name})

            return response

        except Exception as e:
            record_error({"llm.provider": "bedrock", "llm.model": model_name})
            raise

    bedrock_runtime.invoke_model = patched_invoke_model
    print("[TraceLoop Wrapper] Patched boto3.client('bedrock-runtime').invoke_model with metrics")
