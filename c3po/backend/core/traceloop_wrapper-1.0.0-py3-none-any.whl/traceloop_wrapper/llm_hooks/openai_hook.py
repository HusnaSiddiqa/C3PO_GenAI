import openai
from time import perf_counter

from traceloop_wrapper.metrics import (
    record_tokens,
    record_cost,
    record_latency,
    record_request,
    record_error
)
from traceloop_wrapper.usage_utils import extract_usage_openai, calculate_cost

_original_create = openai.ChatCompletion.create

def patched_create(*args, **kwargs):
    model = kwargs.get("model", "unknown")

    start = perf_counter()
    try:
        record_request({"llm.provider": "openai", "llm.model": model})
        response = _original_create(*args, **kwargs)
        duration_ms = (perf_counter() - start) * 1000

        # Token/cost metrics
        usage = extract_usage_openai(response)
        cost = calculate_cost(usage)

        record_tokens(usage.get("total_tokens", 0), {"llm.provider": "openai", "llm.model": model})
        record_cost(cost, {"llm.provider": "openai", "llm.model": model})
        record_latency(duration_ms, {"llm.provider": "openai", "llm.model": model})


        return response

    except Exception:
        record_error({"llm.provider": "openai", "llm.model": model})
        raise

def patch_openai():
    openai.ChatCompletion.create = patched_create
    print("[TraceLoop Wrapper] Patched openai.ChatCompletion.create with metrics")
