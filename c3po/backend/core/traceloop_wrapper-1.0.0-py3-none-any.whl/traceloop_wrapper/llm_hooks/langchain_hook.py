# traceloop_wrapper/llm_hooks/langchain_hook.py
from functools import wraps
from time import perf_counter
from contextvars import ContextVar

from traceloop_wrapper.metrics import (
    record_tokens, record_cost, record_latency, record_request, record_error
)
from traceloop_wrapper.usage_utils import extract_usage_langchain, calculate_cost

_tl_inflight = ContextVar("tl_inflight", default=False)

def _get_model_id(obj):
    return (
        getattr(obj, "model", None)
        or getattr(obj, "endpoint", None)
        or getattr(obj, "model_name", None)
        or getattr(obj, "deployment_name", None)
        or "unknown"
    )

def patch_langchain():
    try:
        try:
            from langchain_core.language_models import BaseLanguageModel  # may exist
        except Exception:
            BaseLanguageModel = None

        try:
            from langchain_core.language_models.chat_models import BaseChatModel
        except Exception:
            BaseChatModel = None

        from langchain_core.runnables.base import Runnable
    except ImportError as e:
        print("[TraceLoop Wrapper] LangChain not installed, skipping patches.", e)
        return

    has_generate = bool(BaseLanguageModel and hasattr(BaseLanguageModel, "generate"))
    has_agenerate = bool(BaseLanguageModel and hasattr(BaseLanguageModel, "agenerate"))

    # 1) Patch BaseLanguageModel.generate/agenerate IF present (older LC)
    if BaseLanguageModel and has_generate and not getattr(BaseLanguageModel, "_tl_patched_generate", False):
        _orig_generate = BaseLanguageModel.generate

        @wraps(_orig_generate)
        def _patched_generate(self, *args, **kwargs):
            if _tl_inflight.get():
                return _orig_generate(self, *args, **kwargs)
            token = _tl_inflight.set(True)
            model_id = _get_model_id(self)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                out = _orig_generate(self, *args, **kwargs)
                usage = extract_usage_langchain(out).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return out
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        BaseLanguageModel.generate = _patched_generate
        BaseLanguageModel._tl_patched_generate = True
        print("[TraceLoop Wrapper] Patched BaseLanguageModel.generate")

    if BaseLanguageModel and has_agenerate and not getattr(BaseLanguageModel, "_tl_patched_agenerate", False):
        _orig_agenerate = BaseLanguageModel.agenerate

        @wraps(_orig_agenerate)
        async def _patched_agenerate(self, *args, **kwargs):
            if _tl_inflight.get():
                return await _orig_agenerate(self, *args, **kwargs)
            token = _tl_inflight.set(True)
            model_id = _get_model_id(self)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                out = await _orig_agenerate(self, *args, **kwargs)
                usage = extract_usage_langchain(out).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return out
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        BaseLanguageModel.agenerate = _patched_agenerate
        BaseLanguageModel._tl_patched_agenerate = True
        print("[TraceLoop Wrapper] Patched BaseLanguageModel.agenerate")

    # 2) Patch BaseChatModel.invoke/ainvoke (exists across versions)
    if BaseChatModel and not getattr(BaseChatModel.invoke, "_tl_patched", False):
        _orig_chat_invoke = BaseChatModel.invoke

        @wraps(_orig_chat_invoke)
        def _patched_chat_invoke(self, *args, **kwargs):
            print("========patched_invoke(BaseChatModel)=======")
            if _tl_inflight.get():
                return _orig_chat_invoke(self, *args, **kwargs)
            token = _tl_inflight.set(True)
            model_id = _get_model_id(self)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                resp = _orig_chat_invoke(self, *args, **kwargs)
                usage = extract_usage_langchain(resp).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return resp
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        BaseChatModel.invoke = _patched_chat_invoke
        BaseChatModel.invoke._tl_patched = True
        print("[TraceLoop Wrapper] Patched BaseChatModel.invoke")

    if BaseChatModel and hasattr(BaseChatModel, "ainvoke") and not getattr(BaseChatModel.ainvoke, "_tl_patched", False):
        _orig_chat_ainvoke = BaseChatModel.ainvoke

        @wraps(_orig_chat_ainvoke)
        async def _patched_chat_ainvoke(self, *args, **kwargs):
            if _tl_inflight.get():
                return await _orig_chat_ainvoke(self, *args, **kwargs)
            token = _tl_inflight.set(True)
            model_id = _get_model_id(self)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                resp = await _orig_chat_ainvoke(self, *args, **kwargs)
                usage = extract_usage_langchain(resp).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return resp
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        BaseChatModel.ainvoke = _patched_chat_ainvoke
        BaseChatModel.ainvoke._tl_patched = True
        print("[TraceLoop Wrapper] Patched BaseChatModel.ainvoke")

    # 3) Safety net: patch Runnable.(a)invoke (covers RunnableBinding from bind_tools)
    #    We also record tokens here (since generate may not exist).
    from langchain_core.runnables.base import Runnable

    if not getattr(Runnable.invoke, "_tl_patched", False):
        _orig_runnable_invoke = Runnable.invoke

        @wraps(_orig_runnable_invoke)
        def _patched_runnable_invoke(self, input, **kwargs):
            # Find inner runnable if this is a binding
            inner = getattr(self, "runnable", None) or getattr(self, "bound", None) or self
            is_model = False
            if BaseLanguageModel and isinstance(inner, BaseLanguageModel):
                is_model = True
            elif BaseChatModel and isinstance(inner, BaseChatModel):
                is_model = True

            if not is_model or _tl_inflight.get():
                return _orig_runnable_invoke(self, input, **kwargs)

            token = _tl_inflight.set(True)
            model_id = _get_model_id(inner)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                out = _orig_runnable_invoke(self, input, **kwargs)
                usage = extract_usage_langchain(out).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return out
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        Runnable.invoke = _patched_runnable_invoke
        Runnable.invoke._tl_patched = True
        print("[TraceLoop Wrapper] Patched Runnable.invoke")

    if hasattr(Runnable, "ainvoke") and not getattr(Runnable.ainvoke, "_tl_patched", False):
        _orig_runnable_ainvoke = Runnable.ainvoke

        @wraps(_orig_runnable_ainvoke)
        async def _patched_runnable_ainvoke(self, input, **kwargs):
            inner = getattr(self, "runnable", None) or getattr(self, "bound", None) or self
            is_model = False
            if BaseLanguageModel and isinstance(inner, BaseLanguageModel):
                is_model = True
            elif BaseChatModel and isinstance(inner, BaseChatModel):
                is_model = True

            if not is_model or _tl_inflight.get():
                return await _orig_runnable_ainvoke(self, input, **kwargs)

            token = _tl_inflight.set(True)
            model_id = _get_model_id(inner)
            start = perf_counter()
            try:
                record_request({"llm.model": str(model_id)})
                out = await _orig_runnable_ainvoke(self, input, **kwargs)
                usage = extract_usage_langchain(out).get("token_usage", {}) or {}
                record_tokens(usage.get("total_tokens", 0), {"llm.model": str(model_id)})
                record_cost(calculate_cost(usage), {"llm.model": str(model_id)})
                return out
            except Exception:
                record_error({"llm.model": str(model_id)})
                raise
            finally:
                record_latency((perf_counter() - start) * 1000, {"llm.model": str(model_id)})
                _tl_inflight.reset(token)

        Runnable.ainvoke = _patched_runnable_ainvoke
        Runnable.ainvoke._tl_patched = True
        print("[TraceLoop Wrapper] Patched Runnable.ainvoke")
