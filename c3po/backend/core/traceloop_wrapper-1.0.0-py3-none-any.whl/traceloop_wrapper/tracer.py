import os
from traceloop.sdk import Traceloop
from traceloop_wrapper.context import get_user_context

def setup_tracer(service_name, otlp_endpoint=None, token=None):

    endpoint = otlp_endpoint or os.getenv("TRACELOOP_BASE_URL")
    if not endpoint:
        print("[TraceLoop Wrapper] Warning: No OTLP endpoint configured. Telemetry will not be exported.")
        return

    os.environ["TRACELOOP_BASE_URL"] = endpoint
    os.environ[
        "TRACELOOP_HEADERS"] = token or os.getenv("TRACELOOP_HEADERS")
    os.environ["OTEL_EXPORTER_OTLP_METRICS_TEMPORALITY_PREFERENCE"] = "delta"
    context = get_user_context()
    print("Tracer User Context:", context)
    Traceloop.init(app_name=service_name, resource_attributes=context)

    print(f"[TraceLoop Wrapper] Tracer initialized and exporting to: {endpoint}")
