from langchain_aws import ChatBedrock
from typing import Any


class BedrockProvider:

    def __init__(
        self,
        model_name: str = "anthropic.claude-3-sonnet-20240229",
        region: str = "us-west-2",
        **kwargs: Any,
    ):
        self.model_name = model_name
        self.region = region
        self.extra_kwargs = kwargs

    def get_llm(self) -> ChatBedrock:
        return ChatBedrock(
            model=self.model_name,
            region=self.region,
            **self.extra_kwargs,
        )
