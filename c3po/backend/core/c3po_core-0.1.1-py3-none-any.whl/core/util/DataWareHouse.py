from dotenv import load_dotenv

load_dotenv()
from databricks import sql
from datetime import datetime
import os
import pandas as pd
from databricks.sql.exc import (
    RequestError
)


class DataWarehouse:
    def __init__(self, host_name, http_path, access_token):
        self.host_name = host_name
        self.http_path = http_path
        self.access_token = access_token
        self.connection = None
        self.cursor = None


    def connect(self):
        return sql.connect(
                server_hostname=self.host_name,
                http_path=self.http_path,
                access_token=self.access_token,
                _tls_no_verify=True
            )

    def format_datetime_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        for col in df.columns:
            col_dtype = df[col].dtype
            if col_dtype == 'object':
                try:
                    converted = pd.to_datetime(df[col], errors='coerce')
                    if converted.notna().sum() > 0:
                        df[col] = converted.dt.strftime('%Y-%m-%d')
                except Exception:
                    pass
            elif pd.api.types.is_datetime64_any_dtype(col_dtype):
                df[col] = df[col].dt.strftime('%Y-%m-%d')
        return df

    def get_data_from_wareshouse(self, sql_query, retry_times=0):
        try:
            with self.connect() as conn:
                cursor = conn.cursor()
                print("In warehouse executing")
                cursor.execute("SET STATEMENT_TIMEOUT = 1000;")
                result = pd.DataFrame(cursor.execute(sql_query).fetchall())
                if result.empty:
                    raise ValueError("Query has returned no data")
                result.columns = [elem[0] for elem in cursor.description]
                result = self.format_datetime_columns(result)

                print(result.head())

                return result.to_json(orient="records")
        except RequestError as e:
            print("Here is the error while connecting at RequestError:", e)
            print('Retrying...', retry_times)
            if retry_times >= 3:
                return ''
            return self.get_data_from_wareshouse(sql_query, retry_times=retry_times + 1)

        except Exception as e:
            print(f"Error in sql warehouse {e}")
            raise e
