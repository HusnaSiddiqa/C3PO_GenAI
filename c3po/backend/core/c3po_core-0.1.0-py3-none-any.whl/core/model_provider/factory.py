from typing import Optional
from core.model_provider.bedrock_provider import BedrockProvider
from core.model_provider.mosaic_provider import MosaicProvider
from langchain_core.language_models import BaseChatModel


class ModelFactory:
    @staticmethod
    def create_provider(
        provider: str,
        model_name: str,
        api_key: Optional[str] = None,
        region: str = "us-east-1",
        base_url: str = "https://api.mosaic.ai/v1"
    ) -> BaseChatModel:
        
        provider = provider.lower()
        if provider == "bedrock":
            return BedrockProvider(model_name=model_name, region=region)
        elif provider == "mosaic":
            if not api_key:
                raise ValueError("API key is required for Mosaic provider")
            return MosaicProvider(model_name=model_name, api_key=api_key, base_url=base_url)
        else:
            raise ValueError(f"Unknown provider: {provider}") 