import boto3

class MemoryStore:
    def __init__(self, bucket_name: str, prefix: str, region_name: str = "us-west-2"):
        self.bucket_name = bucket_name
        self.prefix = prefix
        self.s3 = boto3.client("s3", region_name=region_name)

    def search(self, user_name: str, agent_name: str, **kwargs):
        key_parts = [user_name, agent_name]
        conversation_id = kwargs.get("conversation_id")
        if conversation_id:
            key_parts.append(str(conversation_id))
        s3_key = self.prefix + "/".join(key_parts) if self.prefix else "#".join(key_parts)
       
        try:
            response = self.s3.get_object(Bucket=self.bucket_name, Key=s3_key)
            content = response["Body"].read().decode("utf-8")
            return content
        except self.s3.exceptions.NoSuchKey:
            return None
        except Exception as e:
            print(f"Error searching memory: {e}")
            return None

    def get_store(bucket_name: str, prefix: str, region_name: str = "us-west-2") -> MemoryStore:
        return MemoryStore(bucket_name, prefix, region_name)
