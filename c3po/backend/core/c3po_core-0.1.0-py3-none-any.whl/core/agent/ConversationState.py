from dataclasses import dataclass
from typing import List, Dict

@dataclass
class ConversationState:
    messages: List[Dict]
    step: int = 0