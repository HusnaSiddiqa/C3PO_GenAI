from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Type, TypeVar
from fastapi import FastAPI

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
)
from langchain_core.language_models import BaseChatModel
from langgraph.graph import StateGraph, END

from core.agent.ConversationState import ConversationState
from core.agent.AgentExecutor import AgentExecutor

import uvicorn
import httpx

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryPushNotifier, InMemoryTaskStore

TState = TypeVar("TState", bound=ConversationState)


class AgentBase(ABC, Generic[TState]):

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        pass

    def __init__(self, llm: BaseChatModel) -> None:
        self.llm = llm
        self._state_type: Type[TState] = self._state_dataclass()  # type: ignore
        graph_or_agent = self._build_graph()
        if isinstance(graph_or_agent, StateGraph):
            self._agent = graph_or_agent.compile()
        else:
            self._agent = graph_or_agent
        self._executor = AgentExecutor(self)
        self._agent_skill: AgentSkill | None = None

    def invoke(self, messages: List[Dict[str, Any]], **kwargs: Any):
        """Synchronous single-shot call bypassing A2A."""
        return self._agent.invoke({"messages": messages, **kwargs})

    async def ainvoke(self, messages: List[Dict[str, Any]], **kwargs: Any):
        """Async single-shot call bypassing A2A."""
        return await self._agent.ainvoke({"messages": messages, **kwargs})

    @abstractmethod
    def _build_graph(self) -> Any:  # StateGraph or compiled agent
        """Build and return either a StateGraph or a compiled agent."""
        raise NotImplementedError

    def _state_dataclass(self) -> Type[TState]:  # pragma: no cover
        """Override to supply a custom shared-state dataclass."""
        return ConversationState  # type: ignore

    @staticmethod
    def _finish(_: ConversationState) -> str:
        """Helper for static END routing if needed."""
        return END

    def _set_agent_skill(self, agent_skill: AgentSkill) -> Any:  # StateGraph or compiled agent
        self._agent_skill = agent_skill

    def run_server(self, host="0.0.0.0", port=8000, path: str = "/agents/"):
        if self._agent_skill:
            capabilities = AgentCapabilities(streaming=True, pushNotifications=True)
            agent_card = AgentCard(
                name=self.name,
                description=self.description,
                url=f'http://{host}:{port}/',
                version='1.0.0',
                defaultInputModes=['text', 'text/plain'],
                defaultOutputModes=['text', 'text/plain'],
                capabilities=capabilities,
                skills=[self._agent_skill],
            )
            httpx_client = httpx.AsyncClient()
            request_handler = DefaultRequestHandler(
                agent_executor=self._executor,
                task_store=InMemoryTaskStore(),
                push_notifier=InMemoryPushNotifier(httpx_client),
            )
            server = A2AStarletteApplication(
                agent_card=agent_card, http_handler=request_handler
            ).build()
            app = FastAPI()
            app.mount(path, server)
            print(f"Starting A2A agent server at http://{host}:{port}/ with skill '{self._agent_skill.id}'")
            uvicorn.run(app, host=host, port=port)
        else:
            raise Exception("Provide Agent Skills!")
