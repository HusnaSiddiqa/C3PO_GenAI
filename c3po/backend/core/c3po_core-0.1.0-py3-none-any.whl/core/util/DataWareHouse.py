from dotenv import load_dotenv

load_dotenv()
from databricks import sql
from datetime import datetime
import os
import pandas as pd
from databricks.sql.exc import (
    RequestError
)


class DataWarehouse:
    def __init__(self, host_name, http_path, access_token):
        self.host_name = host_name
        self.http_path = http_path
        self.access_token = access_token
        self.connection = None
        self.cursor = None
        self.reconnect()

    def reconnect(self):
        try:
            self.timestamp = datetime.now()
            self.connection = sql.connect(
                server_hostname=self.host_name,
                http_path=self.http_path,
                access_token=self.access_token,
                _tls_no_verify=True
            )
            self.cursor = self.connection.cursor()
            print("Connection established")
        except Exception as e:
            print(f"Error while reconnecting to session at reconnect method : {str(e)}")
            raise e


    def get_data_from_wareshouse(self, sql_query):
        try:
            print("In warehouse executing")
            result = pd.DataFrame(self.cursor.execute(sql_query).fetchall())
            result.columns = [elem[0] for elem in self.cursor.description]
            print(result.head())
            return result.to_dict(orient="records")
        except RequestError as e:
            print("Here is the error while connecting at RequestError:", e)
            print("Access token refreshed at RequestError:", self.access_token)
            self.reconnect()
            print("reconnected successfully at request error exception")
            return self.get_data_from_wareshouse(sql_query)

        except Exception as e:
            print(f"Error in sql warehouse {e}")
            raise e
